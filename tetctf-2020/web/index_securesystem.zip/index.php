<?php 

require_once('dbconnect.php');
$flag = mysqli_query($conn,"SELECT * FROM xxxxxxxxxxxxxxxxxxx")->fetch_assoc()['yyyyyyyyyyyyyyyyyyyy']; //Sorry It's our secret, can't share
?>

<br><br><br><br><center>
Security Check!!! Please enter your ID to prove who are you !!!:
<form action="index.php" method="POST">
        <input name="id" value="" /><br>
        <input type="submit" value="Submit" />
</form>
</center>

<?php

if (isset($_POST['id']) && !empty($_POST['id']))
{
        if (preg_match('/and|or|in|if|case|sleep|benchmark/is' , $_POST['id'])) 
        {
                die('Tet nhat ai lai hack nhau :(, very dangerous key word'); 
        }
        elseif (preg_match('/order.+?by|union.+?select/is' , $_POST['id'])) 
        { 
                die('Tet nhat ai lai hack nhau :(, very dangerous statement'); 
        }
        else
        {
                $user = mysqli_query($conn,"SELECT * FROM users WHERE id=".$_POST['id'])->fetch_assoc()['username']; 
                if($user!=='admin')
                {
                        echo 'Hello '.htmlentities($user);
                        if($user==='admin')
                        {
                                echo 'This can\'t be =]] Just put here for fun lul';
                                die($flag);
                        }
                }
        }
}
?>

