<?php
	ini_set("session.cookie_httponly", 1);
	define('DBHOST', 'THERE IS NOTHING LIKE HOME');
	define('DBUSER', '###CENSORED###');
	define('DBPASS', '###CENSORED###');
	define('DBNAME', '###CENSORED###');
	define('DB_ADMIN', '###CENSORED###');
	define('SALT', '###CENSORED###');
	define('SERVER_ROOT', '###CENSORED###');
	$conn = mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
	$admin_conn = mysqli_connect(DBHOST,DBUSER,DBPASS,DB_ADMIN);

	if ( !$conn ) {
		die("Connection failed : " . mysql_error());
	}

?>
