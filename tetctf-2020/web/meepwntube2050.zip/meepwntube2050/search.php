<?php
include "dbconnect.php";

$_IP = $_SERVER['REMOTE_ADDR'];

if (isset($_GET['search'])) {
		if ($_IP === "45.76.148.212"){
			//local only homie
			$Name = $_GET['search'];
			$_search = mysqli_real_escape_string($admin_conn,$Name);
			$Execquery = mysqli_query($admin_conn, "SELECT id,Name FROM search WHERE Name LIKE '%$_search%' LIMIT 8");
			while ($Result = mysqli_fetch_array($Execquery)) {
				echo "<center>";
				echo "<b><p style='font-size:20px; color:green'>".$Result['Name']."</p></b>";
				echo "<iframe src='video".$Result['id'].".php' width='1200' height='300'></iframe>";
				echo "</center>";
				}
		}
		else {
			$Name = $_GET['search'];
			$_search = mysqli_real_escape_string($conn,$Name);
			$Execquery = mysqli_query($conn, "SELECT id,Name FROM search WHERE Name LIKE '%$_search%' LIMIT 8");
			while ($Result = mysqli_fetch_array($Execquery)) {
				echo "<center>";
				echo "<b><p style='font-size:20px; color:green'>".$Result['Name']."</p></b>";
				echo "<iframe src='video".$Result['id'].".php' width='1200' height='300'></iframe>";
				echo "</center>";
				}
		}
	}

?>
