HelloVietNam return


0x01. Troubeshoot problem
	In case you have problem with "MYSQL_DATABASE_SOCKET" error when deploy local, don't worry, I troubleshoot it for you. Just need to:

		1: $cat /usr/local/lib/python2.X/dist-packages/flaskext/mysql.py | grep "MYSQL_DATABASE_SOCKET" 
			(or: $cat /usr/local/lib/python3.X/dist-packages/flaskext/mysql.py | grep "MYSQL_DATABASE_SOCKET") depend on your python version. 
		2: commented 2 lines:
			#if self.app.config['MYSQL_DATABASE_SOCKET']:
            	#self.connect_args['unix_socket'] = self.app.config['MYSQL_DATABASE_SOCKET']

0x02. This is the 0x02 version of hellovietnam. The 1st version was released in SVATTT2019 final (a CTF for Students and Cybersecurity in Vietnam). So in case you missed this, I also diff two version, the file locate at: hellovietnam.diff (diff -r hellovietnamv1 hellovietnamv2) in source code. Feel free and enjoy the game. 


"Happy && Hack" New Year My Homies.
